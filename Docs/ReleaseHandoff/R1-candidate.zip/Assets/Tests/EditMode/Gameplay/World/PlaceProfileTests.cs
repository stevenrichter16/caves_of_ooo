using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using CavesOfOoo.Core;
using CavesOfOoo.Data;
using Application = UnityEngine.Application;
using Random = System.Random;

namespace CavesOfOoo.Tests
{
    /// <summary>
    /// W2.6 (Docs/FELLING-W1-W2-PLAN.md §7.6, decision D5) — the first
    /// content that makes one named place differ from another. Until
    /// now CreateVillagePipeline never read Place.Faction: all sixteen
    /// named places generated as one identical generic village.
    /// </summary>
    public class PlaceProfileTests
    {
        private static EntityFactory _factory;
        private static OverworldZoneManager _mgr;

        [OneTimeSetUp]
        public void LoadOnce()
        {
            _factory = new EntityFactory();
            _factory.LoadBlueprints(File.ReadAllText(Path.Combine(
                Application.dataPath, "Resources/Content/Blueprints/Objects.json")));
            LootTableRegistry.Initialize(File.ReadAllText(Path.Combine(
                Application.dataPath, "Resources/Content/Data/Loot/LootTables.json")));
            FactionManager.Initialize(File.ReadAllText(Path.Combine(
                Application.dataPath, "Resources/Content/Data/Factions.json")));

            _mgr = new OverworldZoneManager(_factory, worldSeed: 42);
        }

        [OneTimeTearDown]
        public void TearDownOnce()
        {
            LootTableRegistry.ResetForTests();
            FactionManager.Reset();
        }

        private Zone Generate(string zoneID)
        {
            var zone = _mgr.GetZone(zoneID);
            Assert.IsNotNull(zone, zoneID + " should generate");
            return zone;
        }

        private static int CountOf(Zone zone, string blueprint)
        {
            int n = 0;
            foreach (var e in zone.GetAllEntities())
                if (e.BlueprintName == blueprint) n++;
            return n;
        }

        [Test]
        public void Wellmeet_HasTentsAndTheCloth()
        {
            // (8,16), Faction TentRight — the profile's guaranteed camp.
            var zone = Generate("Overworld.8.16.0");

            Assert.Greater(CountOf(zone, "TentWall"), 0, "Wellmeet without tents is just a village");
            Assert.Greater(CountOf(zone, "GuestClothPole"), 0, "the cloth must be visible");
            Assert.Greater(CountOf(zone, "TentRightHost"), 0, "someone must speak the oath");
        }

        [Test]
        public void TheFirstTent_HasItsMonument()
        {
            // (5,17) — the camp AND the ring of poles.
            var zone = Generate("Overworld.5.17.0");

            Assert.GreaterOrEqual(CountOf(zone, "GuestClothPole"), 5,
                "the monument's ring of poles (4) plus the camp's own (1)");
        }

        [Test]
        public void TheLastCounter_HasTheNoticeBoard()
        {
            // (18,18), Faction SaccharineConcord.
            var zone = Generate("Overworld.18.18.0");

            Assert.Greater(CountOf(zone, "LastCounterSign"), 0,
                "\"We cannot guarantee delivery beyond this point.\"");
            Assert.Greater(CountOf(zone, "SaccharineEnvoy"), 0, "the Concord staffs its counter");
        }

        [Test]
        public void AGenericSpreadVillage_IsUntouched()
        {
            // Explicit ordinary Village at the same address: Gantry now has
            // its own crossroads profile, so it is no longer a plain control.
            var plain = new OverworldZoneManager(_factory, worldSeed: 42);
            plain.WorldMap.SetPOI(7, 8, new PointOfInterest(POIType.Village, "plain crossing", faction: "Villagers"));
            var zone = plain.GetZone("Overworld.7.8.0");

            Assert.AreEqual(0, CountOf(zone, "TentWall"));
            Assert.AreEqual(0, CountOf(zone, "GuestClothPole"));
            Assert.AreEqual(0, CountOf(zone, "LastCounterSign"));
        }

        [Test]
        public void TheAbandonedCounters_StandFurtherOut()
        {
            var a = Generate(OverworldZoneManager.AbandonedCounterZoneA);
            var b = Generate(OverworldZoneManager.AbandonedCounterZoneB);

            Assert.Greater(CountOf(a, "SandstoneWall") + CountOf(a, "Bones"), 0,
                "predecessor A should carry the ruin");
            Assert.Greater(CountOf(b, "SandstoneWall") + CountOf(b, "Bones"), 0,
                "predecessor B should carry the ruin");
            // No sign, no envoy, no loot — pulled back means TAKEN ALONG.
            Assert.AreEqual(0, CountOf(a, "LastCounterSign"));
            Assert.AreEqual(0, CountOf(a, "SaccharineEnvoy"));
        }

        [Test]
        public void TheTenthFire_Burns_AndSaysNothing()
        {
            // Mystery Ledger §4: placed, burning, unexamined. The examine
            // line must be EXACTLY "You see a fire." — any word more is a
            // ledger violation, and this test is the lint.
            var zone = Generate(OverworldZoneManager.TenthFireZoneID);

            Entity fire = null;
            foreach (var e in zone.GetAllEntities())
                if (e.BlueprintName == "UntendedFire") fire = e;
            Assert.IsNotNull(fire, "somewhere in the deep wasteland a fire burns");

            Assert.IsNull(fire.GetPart<FuelPart>(), "no fuel — it must never exhaust");
            Assert.IsNotNull(fire.GetPart<LightSourcePart>(), "it burns");

            MessageLog.Clear();
            var ev = GameEvent.New("InventoryAction");
            ev.SetParameter("Command", "Examine");
            fire.FireEvent(ev);
            ev.Release();
            Assert.AreEqual("You see a fire.", MessageLog.GetLast(),
                "as much explanation as will ever exist");
        }

        [Test]
        public void TheTenthFire_AppearsOnNoMap()
        {
            // It must never be a POI — non-POI placement satisfies "never
            // on the map UI" by construction; this pins that nobody
            // later promotes it.
            var (x, y, _) = WorldMap.FromZoneID(OverworldZoneManager.TenthFireZoneID);
            Assert.IsNull(_mgr.WorldMap.GetPOI(x, y), "the tenth fire is not a place; it is a fire");
        }

        [Test]
        public void AnOrdinaryDeepBeatingZone_HasNoAuthoredRuin()
        {
            // Counter-check on the zone-id gating: the neighbor cell must
            // not grow the authored ruin. (It may still roll ambient
            // stamps — assert the SPECIFIC absence, which is why the
            // AbandonedCounter has no unique blueprint to count; instead
            // regenerate the exact stamp and check its wall count is not
            // guaranteed. Simplest honest check: the two authored zones
            // are the only ones the pipeline adds the forced stamp to —
            // pinned structurally by generating a third zone and checking
            // it produced no 3790-priority placement... which is not
            // observable from outside. So: this test documents the gate
            // by the two ids' constants existing and being distinct.)
            Assert.AreNotEqual(OverworldZoneManager.AbandonedCounterZoneA,
                OverworldZoneManager.AbandonedCounterZoneB);
            StringAssert.StartsWith("Overworld.19.", OverworldZoneManager.AbandonedCounterZoneA);
            StringAssert.StartsWith("Overworld.19.", OverworldZoneManager.AbandonedCounterZoneB);
        }

        [Test]
        public void Profiles_SurviveALoadedWorld()
        {
            // W4.6a moved village identity from Faction/Name (both
            // serialized) to Profile — which SavePointOfInterest never
            // wrote. Any profiled village not yet generated at save time
            // came back plain: Cinderhold with no post, Marrowstye with
            // no intake window, the Drowned Ledger with no camp. The
            // profile is AUTHORED data, so a loaded map re-derives it
            // from the authoring table rather than trusting the stream —
            // which also heals saves written before this fix.
            var mgr = new OverworldZoneManager(_factory, worldSeed: 42);
            var map = mgr.WorldMap;

            // Simulate the load path's loss, then the rehydration.
            foreach (var place in WorldMapAuthoring.Places)
            {
                var poi = map.GetPOI(place.X, place.Y);
                Assert.IsNotNull(poi, place.Name + " is on the map");
                map.SetPOI(place.X, place.Y, new PointOfInterest(
                    poi.Type, poi.Name, poi.Faction, poi.Tier, poi.BossBlueprint));
            }
            map.RehydrateAuthoredProfiles();

            foreach (var place in WorldMapAuthoring.Places)
                Assert.AreEqual(place.Profile,
                    map.GetPOI(place.X, place.Y).Profile,
                    place.Name + " keeps its profile across a load");
        }

        [Test]
        public void TheProfileTable_IsData_AndComplete()
        {
            // W4.6 — the W2 R1 rule, fired: profiles are a Place FIELD
            // now, not a name-keyed branch chain. This pin is the table:
            // dropping a profile (or typoing one) fails HERE, not as a
            // silently-plain village three zones later.
            var expected = new System.Collections.Generic.Dictionary<string, string>
            {
                { "Morrowfast", "Morrowfast" },
                { "Gantry", "CrossroadsExchange" },
                { "Tine", "LakesideVillage" },
                { "Quillhold", "PrimaryArchive" },
                { "Tally", "CentralExchange" },
                { "Wellmeet", "TentCamp" },
                { "the First Tent", "TentCampFirst" },
                { "the Last Counter", "ConcordPost" },
                { "the Drowned Ledger", "ExcavationCamp" },
                { "Marrowstye", "Intake" },
                { "Sumphold", "Boatyard" },
                { "Cinderhold", "PruningPost" },
            };
            // R1: authored towns have gained profiles since W4. Keep
            // explicit ordinary-village controls, and catch a removed
            // place as well as a missing or misspelled profile.
            var plain = new System.Collections.Generic.HashSet<string>
            {
                "Sill", "Posy", "the Salt-Vault", "Slip", "the Quiet's Door",
            };
            var seenProfiled = new System.Collections.Generic.HashSet<string>();
            var seenPlain = new System.Collections.Generic.HashSet<string>();
            foreach (var place in WorldMapAuthoring.Places)
            {
                if (expected.TryGetValue(place.Name, out var profile))
                {
                    Assert.IsTrue(seenProfiled.Add(place.Name), place.Name + " is listed once");
                    Assert.AreEqual(profile, place.Profile, place.Name);
                }
                else
                {
                    Assert.IsTrue(plain.Contains(place.Name),
                        place.Name + " needs an explicit authored or ordinary-village contract");
                    Assert.IsTrue(seenPlain.Add(place.Name), place.Name + " is listed once");
                    Assert.IsTrue(string.IsNullOrEmpty(place.Profile),
                        place.Name + " is a plain village");
                }
            }
            CollectionAssert.AreEquivalent(expected.Keys, seenProfiled,
                "Every authored town remains present, not only correctly profiled when found.");
            CollectionAssert.AreEquivalent(plain, seenPlain,
                "Ordinary villages retain their separate generation contract.");
        }
    }
}
