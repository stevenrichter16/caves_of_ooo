using System.Linq;using NUnit.Framework;using CavesOfOoo.Core;using CavesOfOoo.Data;
namespace CavesOfOoo.Tests {
public sealed class DensityLairPersistenceDesignProbe {
 DensityLootTestScope scope;OverworldZoneManager manager;string id;Entity boss;Zone lair;
 [SetUp]public void Setup(){scope=new DensityLootTestScope();manager=OverworldZoneManager.CreateDetached(scope.Factory,64);int x=4,y=9;manager.WorldMap.SetPOI(x,y,new PointOfInterest(POIType.Lair,"ownership probe",null,2,"MarlbackWallkeeper"));id=WorldMap.ToZoneID(x,y,0);lair=manager.GetZone(id);Assert.NotNull(lair);boss=lair.GetReadOnlyEntities().Single(e=>e.BlueprintName=="MarlbackWallkeeper");}
 [TearDown]public void Cleanup(){scope.Dispose();}
 [Test]public void CachedRevisitKeepsTheActualLivingBossAndDamage(){boss.GetStat("Hitpoints").BaseValue=7;Assert.AreSame(lair,manager.GetZone(id));Assert.AreSame(boss,manager.GetZone(id).GetReadOnlyEntities().Single(e=>e.BlueprintName=="MarlbackWallkeeper"));Assert.AreEqual(7,boss.GetStat("Hitpoints").BaseValue);}
 [Test]public void UnloadMustNotReplaceTheActualLivingBossOrHealIt(){boss.GetStat("Hitpoints").BaseValue=7;manager.UnloadZone(id);var again=manager.GetZone(id);Assert.AreSame(boss,again.GetReadOnlyEntities().Single(e=>e.BlueprintName=="MarlbackWallkeeper"));}
 [Test]public void UnloadMustNotRespawnACommittedDeadBoss(){boss.SetTag("_DeathHandled");boss.GetStat("Hitpoints").BaseValue=0;lair.RemoveEntity(boss);manager.UnloadZone(id);Assert.False(manager.GetZone(id).GetReadOnlyEntities().Any(e=>e.BlueprintName=="MarlbackWallkeeper"));}
 [Test]public void UnloadMustPreserveTheActualDepletedRewardOwner(){var chest=scope.Factory.CreateEntity("Chest");chest.GetPart<ContainerPart>().Contents.Clear();Assert.True(lair.AddEntity(chest,40,13));manager.UnloadZone(id);Assert.True(manager.GetZone(id).GetReadOnlyEntities().Any(e=>ReferenceEquals(e,chest)));}
}}
