#!/bin/sh
# Launch the Linux player from this package, including paths containing spaces.
set -eu
package_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$package_dir"
exec "$package_dir/CavesOfOoo.x86_64" -screen-width 1280 -screen-height 800 -screen-fullscreen 1 "$@"
