#!/bin/bash
set -eu
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq xvfb x11vnc novnc websockify fluxbox libgtk-3-0 libglu1-mesa libgl1-mesa-dri libglx-mesa0 mesa-utils mesa-vulkan-drivers libvulkan1 libxrandr2 libxcursor1 libxi6 libxinerama1 libasound2 libpulse0 ca-certificates > /audit/packages.log 2>&1
Xvfb :99 -screen 0 1280x800x24 -ac > /audit/xvfb.log 2>&1 &
for i in $(seq 1 30); do test -e /tmp/.X11-unix/X99 && break; sleep 1; done
fluxbox > /audit/fluxbox.log 2>&1 &
x11vnc -display :99 -forever -shared -nopw -rfbport 5900 > /audit/vnc.log 2>&1 &
websockify --web=/usr/share/novnc 6080 localhost:5900 > /audit/web.log 2>&1 &
glxinfo -B > /audit/graphics.txt 2>&1
cd /game
./CavesOfOoo.x86_64 -screen-width 1280 -screen-height 800 -screen-fullscreen 0 -logFile /audit/player-original.log > /audit/stdout.log 2>&1 &
wait
