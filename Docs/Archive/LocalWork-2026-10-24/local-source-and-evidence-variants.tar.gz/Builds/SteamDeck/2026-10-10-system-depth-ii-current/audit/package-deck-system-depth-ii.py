#!/usr/bin/env python3
"""Package the already-built System Depth II Linux player; never builds or commits.

Usage:
  python3 /tmp/package-deck-system-depth-ii.py /absolute/final-play/report.json --source-commit FINAL_HEAD --editmode-report /absolute/final-tests.xml

Defaults:
  Builds/SteamDeck/2026-10-10-system-depth-ii-current/audit/build-report.json
  Docs/Verification/SystemDepthII/native-final-integration.xml
--source-commit must explicitly name the final, current HEAD.
"""
import argparse
import datetime
import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as ET


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def stream_sha(stream):
    digest = hashlib.sha256()
    while block := stream.read(1024 * 1024):
        digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('native_report', type=pathlib.Path)
    parser.add_argument('--repo', type=pathlib.Path, default=pathlib.Path('/Users/steven/caves-of-ooo'))
    parser.add_argument('--build-report', type=pathlib.Path)
    parser.add_argument('--editmode-report', type=pathlib.Path)
    parser.add_argument('--source-commit', required=True)
    parser.add_argument('--folder', type=pathlib.Path, default=pathlib.Path('Builds/SteamDeck/2026-10-10-system-depth-ii-current'))
    args = parser.parse_args()
    repo = args.repo.resolve()
    folder = (args.folder if args.folder.is_absolute() else repo / args.folder).resolve()
    require(folder.is_relative_to((repo / 'Builds/SteamDeck').resolve()) and folder.name.endswith('-current'),
            'Package destination must be a SteamDeck build folder ending -current.')
    player = folder / 'CavesOfOoo-current'
    archive_root = player.name
    audit = folder / 'audit'
    build_path = (args.build_report or audit / 'build-report.json').resolve()
    tests_path = (args.editmode_report or repo / 'Docs/Verification/SystemDepthII/native-final-integration.xml').resolve()
    native_path = args.native_report.resolve()

    def git(*arguments):
        return subprocess.check_output(['git', *arguments], cwd=repo, text=True).strip()

    commit = git('rev-parse', 'HEAD')
    require(re.fullmatch(r'[0-9a-f]{40}', commit), 'Expected a full current HEAD commit.')
    if args.source_commit:
        require(git('rev-parse', args.source_commit + '^{commit}') == commit, '--source-commit differs from current HEAD.')
    # Keep revision metadata honest. Output receipts and unrelated art work are
    # not forced into a commit; production code and shipped instructions must be.
    source_scopes = ('Assets/Scripts', 'Assets/Editor', 'Assets/Resources', 'Assets/Scenes', 'Tools/SteamDeck')
    changed = git('diff', '--name-only', 'HEAD', '--', *source_scopes)
    require(not changed, 'Commit the final production source/instructions first:\n' + changed)
    untracked = git('ls-files', '--others', '--exclude-standard', '--', *source_scopes).splitlines()
    relevant_untracked = [name for name in untracked if pathlib.Path(name).suffix in ('.cs', '.asmdef', '.asmref')
                          or name.startswith(('Assets/Resources/', 'Assets/Scenes/', 'Tools/SteamDeck/'))]
    require(not relevant_untracked, 'Uncommitted production source/instructions:\n' + '\n'.join(relevant_untracked))

    build = read_json(build_path)
    data = build.get('data', {})
    require(build.get('success') is True and data.get('result') == 'succeeded'
            and data.get('errors') == 0, 'Fresh build report is not successful with zero errors.')
    require(data.get('platform') == 'StandaloneLinux64', 'Build report is not Linux x86_64.')
    started = datetime.datetime.fromisoformat(data['started_at'].replace('Z', '+00:00'))
    completed = datetime.datetime.fromisoformat(data['completed_at'].replace('Z', '+00:00'))
    commit_time = int(git('show', '-s', '--format=%ct', commit))
    require(started.tzinfo is not None and completed.tzinfo is not None
            and completed >= started and started.timestamp() >= commit_time,
            'Build must be completed after the final HEAD commit; regenerate stale build evidence.')
    reported_output = pathlib.Path(data['output_path'])
    if not reported_output.is_absolute():
        reported_output = repo / reported_output
    executable = player / 'CavesOfOoo.x86_64'
    require(reported_output.resolve() == executable.resolve(), 'Build report points at another build directory.')
    require(executable.is_file() and (player / 'CavesOfOoo_Data').is_dir()
            and (player / 'UnityPlayer.so').is_file(), 'Fresh Linux player payload is incomplete.')
    with executable.open('rb') as stream:
        elf = stream.read(20)
    require(len(elf) == 20 and elf[:4] == b'\x7fELF' and elf[4:6] == b'\x02\x01'
            and int.from_bytes(elf[18:20], 'little') == 62, 'Player is not a 64-bit little-endian x86_64 ELF.')

    test_receipt = ET.parse(tests_path).getroot()
    require(test_receipt.tag == 'test-run', 'Expected the final native NUnit test-run XML.')
    summary = {key: int(test_receipt.get(key, '-1')) for key in ('total', 'passed', 'failed', 'skipped', 'inconclusive')}
    total = summary['total']
    test_cases = list(test_receipt.iter('test-case'))
    require(test_receipt.get('result') == 'Passed' and total > 0 and summary['passed'] > 0
            and summary['failed'] == 0 and summary['inconclusive'] == 0
            and summary['passed'] + summary['skipped'] == total and len(test_cases) == total,
            'Final native NUnit receipt has failures or incomplete/inconsistent counts.')
    require(sum(case.get('result') == 'Passed' for case in test_cases) == summary['passed']
            and sum(case.get('result') == 'Skipped' for case in test_cases) == summary['skipped'],
            'Individual NUnit results disagree with the summary.')
    tests = {'mode': 'EditMode', 'id': test_receipt.get('id'), 'start_time': test_receipt.get('start-time'),
             'end_time': test_receipt.get('end-time'), 'duration_seconds': float(test_receipt.get('duration', '0'))}

    native = read_json(native_path)
    require(native.get('mode') == 'system-depth-ii-connections' and native.get('complete') is True
            and native.get('errorsFinalized') is True and native.get('failures') == 0
            and native.get('unexpectedErrors') == 0 and not native.get('fatal'),
            'Final native System Depth II audit did not complete without failures/errors.')
    cases = native.get('audit', [])
    require(native.get('cases', 0) > 0 and len(cases) == native['cases']
            and all(isinstance(case, str) and case.startswith('PASS ') for case in cases),
            'Native check count or individual PASS records disagree.')
    screenshots = native.get('screenshots', [])
    require(screenshots and all(pathlib.Path(name).is_file() for name in screenshots), 'Native screenshot evidence is missing.')

    archive = folder / 'CavesOfOoo-SteamDeck-system-depth-ii-current.tar.gz'
    require(not archive.exists() and not archive.is_symlink(),
            'Refusing to replace an existing delivery archive: ' + str(archive))
    require(not audit.is_symlink() and audit.resolve().is_relative_to(folder),
            'Audit directory must resolve inside the build folder without an alias.')
    receipt_inputs = {'build': build_path, 'final_editmode': tests_path, 'final_native_connections': native_path}
    derived_outputs = [archive.with_name(archive.name + '.partial'),
                       archive.with_suffix(archive.suffix + '.sha256'), audit / 'package-checks.json']
    derived_outputs.extend(audit / (name + '-receipt' + source.suffix)
                           for name, source in receipt_inputs.items())
    for path in derived_outputs:
        require(not path.is_symlink(), 'Refusing to write through an output alias: ' + str(path))

    # Validate destination links before any copy, chmod or metadata write.
    require(not player.is_symlink() and player.resolve().is_relative_to(folder), 'Player directory is an external alias.')
    payload_root = player.resolve()
    for path in player.rglob('*'):
        if path.is_symlink():
            require(not pathlib.Path(path.readlink()).is_absolute() and path.resolve().is_relative_to(payload_root),
                    'External or nonportable payload symlink: ' + str(path))
    for name in ('Launch-CavesOfOoo.sh', 'README-Steam-Deck.md', 'build-info.json', 'SHA256SUMS'):
        require(not (player / name).is_symlink(), 'Refusing to replace metadata through a symlink: ' + name)

    # Validate all evidence before modifying the fresh player or creating an archive.
    audit.mkdir(parents=True, exist_ok=True)
    for name in ('Launch-CavesOfOoo.sh', 'README-Steam-Deck.md'):
        source = repo / 'Tools/SteamDeck' / name
        require(source.is_file(), 'Missing shipped instruction/launcher: ' + str(source))
        shutil.copyfile(source, player / name)
    readme = player / 'README-Steam-Deck.md'
    text = readme.read_text().replace('# Caves of Ooo — Steam Deck Qud-style controls update', '# Caves of Ooo — Steam Deck current build')
    text = text.replace('Replace the entire old `CavesOfOoo` folder at the same location.',
                        'Keep the new `CavesOfOoo-current` folder together. You may keep the old copy separately.')
    text = text.replace("Launch the existing non-Steam shortcut pointing at `CavesOfOoo.x86_64`.\n   If you move the folder, update the shortcut's target and Start In paths.",
                        'Point your non-Steam shortcut at `CavesOfOoo-current/CavesOfOoo.x86_64`.\n   Set Start In to the `CavesOfOoo-current` folder; an old shortcut must be updated.')
    readme.write_text(text)
    for name in ('CavesOfOoo.x86_64', 'Launch-CavesOfOoo.sh'):
        (player / name).chmod(0o755)
    receipt_hashes = {}
    for name, source in receipt_inputs.items():
        destination = audit / (name + '-receipt' + source.suffix)
        if source != destination.resolve():
            shutil.copyfile(source, destination)
        receipt_hashes[name] = {'file': destination.name, 'sha256': sha(destination)}
    version = re.search(r'^m_EditorVersion:\s*(.+)$', (repo / 'ProjectSettings/ProjectVersion.txt').read_text(), re.M)
    info = {
        'commit': commit,
        'source_tree': git('rev-parse', 'HEAD^{tree}'),
        'packaged_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'unity_version': version.group(1) if version else None,
        'platform': 'Linux x86_64',
        'package_root': archive_root,
        'packaging_script_sha256': sha(pathlib.Path(__file__)),
        'delivery_readme_adjustment': 'The committed Steam Deck README has only its title and package folder/shortcut paths adapted for CavesOfOoo-current.',
        'build_report': build,
        'receipt_sha256': receipt_hashes,
        'tracked_configuration_changes_at_packaging': git('diff', '--name-only', 'HEAD', '--', 'Packages', 'ProjectSettings').splitlines(),
        'validation': {
            'selected_final_editmode': {**tests, **summary},
            'selected_final_connections_native': {
                'run_id': native['runId'], 'mode': native['mode'], 'cases': native['cases'],
                'passed': len(cases), 'failed': native['failures'], 'unexpected_errors': native['unexpectedErrors'],
                'complete': native['complete'], 'seconds': native.get('seconds'), 'screenshots': len(screenshots),
                'checks': cases, 'can_verify': native.get('canVerify'), 'cannot_verify': native.get('cannotVerify'),
            },
            'source_correspondence': 'The coordinated implementation workflow selected these final receipts before committing unchanged production source. Receipt files do not independently embed a source hash.',
            'source_correspondence_note': 'These receipts do not contain a source revision hash. Their correspondence to this HEAD is established by the coordinated test, commit, then build workflow, not by machine-verified receipt revision identity.',
            'counting_note': 'EditMode tests and native scenario checks are distinct evidence and are not added together. Counts come directly from the final receipts; skipped tests remain explicit.',
            'physical_steam_deck_tested': False,
            'physical_controller_audio_performance_tested': False,
            'linux_player_runtime_tested': False,
            'performance_note': 'This package adds the System Depth II gameplay connections. Native arranged integration and selected EditMode tests do not establish Steam Deck frame rate, thermals, battery life, audio, physical controller behavior or natural discovery rates.',
        },
    }
    (player / 'build-info.json').write_text(json.dumps(info, indent=2) + '\n')

    # A package must not follow an external symlink into unrelated host files.
    payload_root = player.resolve()
    for path in player.rglob('*'):
        if path.is_symlink():
            require(not pathlib.Path(path.readlink()).is_absolute() and path.resolve().is_relative_to(payload_root),
                    'External or nonportable payload symlink: ' + str(path))
    files = sorted(path for path in player.rglob('*') if path.is_file()
                   and path != player / 'SHA256SUMS' and path.name != '.DS_Store')
    checks = {path.relative_to(player).as_posix(): sha(path) for path in files}
    require(all('\n' not in name and '\r' not in name for name in checks), 'Unsupported newline in payload filename.')
    manifest = ''.join(f'{value}  {name}\n' for name, value in checks.items()).encode()
    (player / 'SHA256SUMS').write_bytes(manifest)
    partial = archive.with_name(archive.name + '.partial')
    try:
        with tarfile.open(partial, 'w:gz', compresslevel=6) as tar:
            tar.add(player, arcname=archive_root, filter=lambda item:
                    None if pathlib.PurePosixPath(item.name).name == '.DS_Store' else item)
        with tarfile.open(partial, 'r:gz') as tar:
            members = tar.getmembers()
            names = [member.name for member in members]
            require(len(names) == len(set(names)), 'Duplicate archive member names.')
            require(all(name == archive_root or name.startswith(archive_root + '/') for name in names)
                    and all('..' not in pathlib.PurePosixPath(name).parts for name in names), 'Unsafe archive path.')
            archived_files = {member.name.removeprefix(archive_root + '/') for member in members
                              if member.isfile() or member.issym() or member.islnk()}
            require(archived_files == set(checks) | {'SHA256SUMS'}, 'Archive file list differs from checksum manifest.')
            for name, expected in checks.items():
                stream = tar.extractfile(archive_root + '/' + name)
                require(stream is not None, 'Missing archive payload: ' + name)
                with stream:
                    require(stream_sha(stream) == expected, 'Archive digest mismatch: ' + name)
            with tar.extractfile(archive_root + '/SHA256SUMS') as stream:
                require(stream.read() == manifest, 'Archived checksum manifest differs.')
            for name in ('CavesOfOoo.x86_64', 'Launch-CavesOfOoo.sh'):
                require(tar.getmember(archive_root + '/' + name).mode & 0o111 == 0o111, 'Executable permission missing: ' + name)
        require(git('rev-parse', 'HEAD') == commit, 'HEAD changed during packaging.')
        partial.replace(archive)
    finally:
        if partial.exists():
            partial.unlink()
    archive_sha = sha(archive)
    archive.with_suffix(archive.suffix + '.sha256').write_text(archive_sha + '  ' + archive.name + '\n')
    result = {'archive': str(archive), 'commit': commit, 'bytes': archive.stat().st_size,
              'sha256': archive_sha, 'verified_payload_files': len(checks),
              'archive_stream_digests_match': True, 'archive_file_list_matches': True,
              'executable_permissions': True, 'editmode': summary,
              'native_run_id': native['runId'], 'native_cases': native['cases'], 'native_failures': 0,
              'physical_steam_deck_tested': False}
    (audit / 'package-checks.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
