"""Original deterministic Ember sound synthesis. Run with Python + NumPy/SciPy + FFmpeg."""
import hashlib
import json
import subprocess
from pathlib import Path
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt, resample_poly

ROOT=Path(__file__).resolve().parent
SR=48000

def noise(rng,n,low,high):
    x=sosfilt(butter(2,[low,high],btype='bandpass',fs=SR,output='sos'),rng.normal(size=n))
    return x/(np.sqrt(np.mean(x*x))+1e-12)

def envelope(t,attack,decay):
    return (1-np.exp(-t/attack))**2*np.exp(-t/decay)

def finish(x):
    x=sosfilt(butter(2,75,btype='highpass',fs=SR,output='sos'),x)
    x=sosfilt(butter(2,7000,btype='lowpass',fs=SR,output='sos'),x)
    ramp=np.sin(np.linspace(0,np.pi/2,480))**2
    x[:480]*=ramp; x[-2400:]*=np.linspace(1,0,2400)**3
    x[-480:]*=ramp[::-1]
    return x

def synth(seed):
    rng=np.random.default_rng(seed)
    t=np.arange(int(.22*SR))/SR
    # Breath through burning wood: no bass oscillator, thump or pitched strike.
    charge=(.06*noise(rng,len(t),550,2800)+.04*noise(rng,len(t),2400,6500))*np.sin(np.pi*t/.22)**.7
    charge+=wood_crackle(rng,len(t),19,.045,.19)*np.sin(np.pi*t/.22)

    t=np.arange(int(.4*SR))/SR
    # An irregular gust sustains across the wake instead of decaying like a drum.
    knots=rng.uniform(.65,1.25,11)
    turbulence=np.interp(t,np.linspace(0,.4,len(knots)),knots)
    gust=(1-np.exp(-t/.015))*(1/(1+np.exp((t-.265)/.027)))
    airy=.17*noise(rng,len(t),650,3200)+.115*noise(rng,len(t),2800,6800)
    flight=airy*turbulence*gust
    # Tiny dense fire crackles under larger, irregular splintering wood snaps.
    flight+=wood_crackle(rng,len(t),74,.1,.31)*gust
    flight+=wood_crackle(rng,len(t),7,.25,.26)*gust

    t=np.arange(int(.36*SR))/SR
    # Small oxygen-fed flare and dying cinders, without a separate impact knock.
    impact=(.08*noise(rng,len(t),1400,5800)+.035*noise(rng,len(t),700,2100))*envelope(t,.008,.072)
    impact+=wood_crackle(rng,len(t),24,.065,.22)*envelope(t,.004,.09)
    return {k:finish(v) for k,v in [('charge',charge),('flight',flight),('impact',impact)]}

def wood_crackle(rng,n,count,amount,last):
    x=np.zeros(n)
    for _ in range(count):
        start=int(rng.uniform(.008,last)*SR)
        length=min(int(rng.uniform(.005,.024)*SR),n-start)
        t=np.arange(length)/SR
        low=rng.uniform(850,2300)
        grain=noise(rng,length,low,min(7200,low*2.8))
        env=(1-np.exp(-t/.00035))*np.exp(-t/rng.uniform(.0018,.005))
        env*=np.sin(np.linspace(0,np.pi/2,length))[::-1]**2
        x[start:start+length]+=amount*rng.uniform(.25,1)*grain*env
    return x

def composite(stems):
    x=np.zeros(38400)
    for kind,start in [('charge',0),('flight',10560),('impact',14160)]:
        y=stems[kind];x[start:start+len(y)]+=y
    return x

def main():
    for folder in ['wav','float-masters','preview']: (ROOT/folder).mkdir(exist_ok=True)
    variants=[synth(seed) for seed in [7301,7302,7303]]
    for v in variants:v['composite']=composite(v)
    peak=max(np.max(np.abs(resample_poly(x,4,1))) for v in variants for x in v.values())
    gain=10**(-4/20)/peak
    receipt={'sampleRate':SR,'bits':24,'channels':1,'seeds':[7301,7302,7303],
        'sharedGain':float(gain),'releaseSeconds':.22,'exampleContactSeconds':.295,
        'revision':2,'direction':'Wind blowing through crackling burning wood; no tonal drum body.',
        'provenance':'Original procedural synthesis; no external samples or AI service.', 'files':{}}
    for i,v in enumerate(variants,1):
        for kind,x in v.items():
            x*=gain
            name=f'ember_spit_{kind}_{i:02d}.wav'
            src=ROOT/'float-masters'/name;dst=ROOT/'wav'/name
            wavfile.write(src,SR,x.astype(np.float32))
            subprocess.run(['ffmpeg','-v','error','-y','-i',str(src),'-c:a','pcm_s24le',str(dst)],check=True)
            receipt['files'][str(dst.relative_to(ROOT))]=hashlib.sha256(dst.read_bytes()).hexdigest()
    # Three normal-speed casts, separated by quiet space; no gain change.
    reel=np.concatenate([np.zeros(int(.25*SR))]+[np.concatenate([v['composite'],np.zeros(int(.55*SR))]) for v in variants])
    src=ROOT/'preview'/'ember_spit_three_variations_float.wav'
    dst=ROOT/'preview'/'ember_spit_three_variations.wav'
    wavfile.write(src,SR,reel.astype(np.float32))
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(src),'-c:a','pcm_s24le',str(dst)],check=True)
    receipt['files'][str(dst.relative_to(ROOT))]=hashlib.sha256(dst.read_bytes()).hexdigest()
    revision_preview=ROOT/'preview'/'ember_spit_wind_fire_v2.wav'
    revision_preview.write_bytes(dst.read_bytes())
    receipt['files'][str(revision_preview.relative_to(ROOT))]=hashlib.sha256(revision_preview.read_bytes()).hexdigest()
    (ROOT/'manifest.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
